package com.MagadhUniversity.HRMS_MU;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsMuApplicationTests {

	@Test
	void contextLoads() {
	}

}
