package com.MagadhUniversity.HRMS_MU;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrmsMuApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmsMuApplication.class, args);
	}

}
